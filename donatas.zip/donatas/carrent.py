import json
from tkinter import messagebox, ttk, Tk, Toplevel, Frame, Label, Entry, Button, Scrollbar, StringVar, IntVar, END, CENTER, Y, RIGHT

class DataManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self.CARS_FILE = 'cars.json'
        self.USERS_FILE = 'users.json'
        self.MANAGES_FILE = 'manages.json'
        self.COUNTERS_FILE = 'counters.json'
        self.cars = {}
        self.users = {}
        self.manages = {}
        self.car_id_counter = 1
        self.user_id_counter = 1

    def save_data(self):
        with open(self.CARS_FILE, 'w') as f:
            json.dump(self.cars, f)
        with open(self.USERS_FILE, 'w') as f:
            json.dump(self.users, f)
        with open(self.MANAGES_FILE, 'w') as f:
            json.dump(self.manages, f)
        with open(self.COUNTERS_FILE, 'w') as f:
            json.dump({'car_id_counter': self.car_id_counter, 'user_id_counter': self.user_id_counter}, f)

    def get_cars(self):
        return self.cars

    def get_users(self):
        return self.users

    def get_manages(self):
        return self.manages

    def get_car_id_counter(self):
        return self.car_id_counter

    def get_user_id_counter(self):
        return self.user_id_counter

    def increment_car_id_counter(self):
        self.car_id_counter += 1

    def increment_user_id_counter(self):
        self.user_id_counter += 1

def enter():
    data_manager = DataManager()
    
CARS_FILE = 'cars.json'
USERS_FILE = 'users.json'
MANAGES_FILE = 'manages.json'
COUNTERS_FILE = 'counters.json'

# Laikinai saugomi duomenys
cars = {}
users = {}
manages = {}
car_id_counter = 1
user_id_counter = 1


def save_data():
    with open(CARS_FILE, 'w') as f:
        json.dump(cars, f)
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f)
    with open(MANAGES_FILE, 'w') as f:
        json.dump(manages, f)
    with open(COUNTERS_FILE, 'w') as f:
        json.dump({'car_id_counter': car_id_counter, 'user_id_counter': user_id_counter}, f)

def enter():
    global car_id_counter
    global user_id_counter
    def addcar():
        global car_id_counter
        e1 = car_id_counter
        e2 = ent2.get()
        e3 = ent3.get()
        cars[e1] = {'brand': e2, 'rent': e3, 'available': 'y'}
        car_id_counter += 1
        carid.delete(0, END)
        brand.delete(0, END)
        price.delete(0, END)
        messagebox.showinfo('success', "car inserted!")
        refresh_tree()
        save_data()

    def delcar():
        e1 = int(ent1.get())
        if e1 in cars and cars[e1]['available'] == 'y':
            del cars[e1]
            carid.delete(0, END)
            brand.delete(0, END)
            price.delete(0, END)
            messagebox.showinfo('success', 'car deleted!!')
            refresh_tree()
            save_data()
        else:
            messagebox.showwarning('error', 'car not found or not available!')

    def refresh_tree():
        for i in tree.get_children():
            tree.delete(i)
        for car_id, car_info in cars.items():
            if car_info['available'] == 'y':
                tree.insert('', 'end', values=(car_id, car_info['brand'], car_info['rent']))

    def bookcar():
        global user_id_counter
        a = int(ent4.get())
        b = ent5.get()
        c = ent6.get()
        d = ent7.get()
        e = ent8.get()

        if a in cars and cars[a]['available'] == 'y':
            user_id = user_id_counter
            users[user_id] = {'name': b, 'email': c, 'startdate': d, 'loc': e}
            manages[user_id] = a
            cars[a]['available'] = 'n'
            user_id_counter += 1
            carbook.delete(0, END)
            carname.delete(0, END)
            carmail.delete(0, END)
            cardate.delete(0, END)
            carloc.delete(0, END)
            messagebox.showinfo('success', "car booked")
            refresh_tree()
            save_data()
        else:
            messagebox.showwarning('error', 'car not available or not found!')

    def returncar():
        def rccar():
            s1 = int(bt1.get())
            s2 = int(bt2.get())
            if s2 in manages and manages[s2] == s1:
                cars[s1]['available'] = 'y'
                del manages[s2]
                del users[s2]
                messagebox.showinfo("car returned", "thank u come again!")
                b1.delete(0, END)
                b2.delete(0, END)
                b3.delete(0, END)
                refresh_return_tree()
                refresh_tree()
                save_data()
            else:
                messagebox.showwarning('error', 'car or user not found!')

        def refresh_return_tree():
            for i in tree1.get_children():
                tree1.delete(i)
            for user_id, car_id in manages.items():
                user_info = users[user_id]
                tree1.insert('', 'end', values=(car_id, user_id, user_info['name'], user_info['email']))

        root1 = Toplevel()
        root1.geometry("600x600")
        root1.title("RETURN CAR")
        Label(root1, text="CARS TO BE RETURNED").pack()
        tree1 = ttk.Treeview(root1)
        tree1["show"] = "headings"
        s = ttk.Style(root1)
        s.theme_use("clam")
        tree1["columns"] = ("carid", "userid", "name", "email")
        tree1.column("carid", width=70, minwidth=70, anchor=CENTER)
        tree1.column("userid", width=70, minwidth=70, anchor=CENTER)
        tree1.column("name", width=150, minwidth=150, anchor=CENTER)
        tree1.column("email", width=150, minwidth=150, anchor=CENTER)

        tree1.heading("carid", text="carid", anchor=CENTER)
        tree1.heading("userid", text="userid", anchor=CENTER)
        tree1.heading("name", text="name", anchor=CENTER)
        tree1.heading("email", text="email", anchor=CENTER)

        refresh_return_tree()

        bt1 = IntVar()
        bt2 = IntVar()
        bt3 = StringVar()

        Label(root1, text="CARID").place(x=210, y=270)
        b1 = Entry(root1, textvariable=bt1)
        b1.place(x=260, y=270)

        Label(root1, text="USERID").place(x=210, y=300)
        b2 = Entry(root1, textvariable=bt2)
        b2.place(x=260, y=300)

        Label(root1, text="NAME").place(x=210, y=330)
        b3 = Entry(root1, textvariable=bt3)
        b3.place(x=260, y=330)

        Button(root1, text="RETURN CAR", command=rccar).place(x=250, y=370)

        vsb = ttk.Scrollbar(root1, orient="vertical")
        vsb.configure(command=tree1.yview)
        tree1.configure(yscrollcommand=vsb.set)
        vsb.pack(fill=Y, side=RIGHT)

        tree1.pack()
        root1.mainloop()

    root = Toplevel()
    root.geometry("500x500")
    root.title("DBMS PROJECT")

    notebook = ttk.Notebook(root)
    notebook.pack()

    frame1 = Frame(notebook, width=500, height=500)
    frame2 = Frame(notebook, width=500, height=500)
    frame3 = Frame(notebook, width=500, height=500)

    frame1.pack(fill="both", expand=1)
    frame2.pack(fill="both", expand=1)
    frame3.pack(fill="both", expand=1)

    notebook.add(frame1, text="admin")
    notebook.add(frame2, text="book")
    notebook.add(frame3, text="return")

    ent1 = IntVar()
    ent2 = StringVar()
    ent3 = IntVar()

    Label(frame1, text="WELCOME TO CAR RENTAL SYSTEM").pack()
    Label(frame1, text="CARID").place(x=150, y=50)
    carid = Entry(frame1, textvariable=ent1)
    carid.place(x=200, y=50)

    Label(frame1, text="BRAND").place(x=150, y=80)
    brand = Entry(frame1, textvariable=ent2)
    brand.place(x=200, y=80)

    Label(frame1, text="RENT").place(x=150, y=110)
    price = Entry(frame1, textvariable=ent3)
    price.place(x=200, y=110)

    Button(frame1, text="ADD CAR", command=addcar).place(x=200, y=200)
    Button(frame1, text="DROP CAR", command=delcar).place(x=300, y=200)

    Label(frame2, text="AVAILABLE CARS").pack()

    treescroll = Frame(frame2)
    treescroll.pack()

    scroll = Scrollbar(frame2)
    scroll.pack(side=RIGHT, fill=Y)
    tree = ttk.Treeview(frame2, yscrollcommand=scroll.set)
    scroll.config(command=tree.yview)

    tree['show'] = 'headings'
    s = ttk.Style(root)
    s.theme_use("clam")
    tree.pack()

    tree['columns'] = ("car_id", "brand", "rent")
    tree.column("car_id", width=50, minwidth=50, anchor=CENTER)
    tree.column("brand", width=100, minwidth=100, anchor=CENTER)
    tree.column("rent", width=150, minwidth=150, anchor=CENTER)

    tree.heading("car_id", text="carid", anchor=CENTER)
    tree.heading("brand", text="brand", anchor=CENTER)
    tree.heading("rent", text="rent", anchor=CENTER)

    refresh_tree()

    ent4 = IntVar()
    ent5 = StringVar()
    ent6 = StringVar()
    ent7 = StringVar()
    ent8 = StringVar()

    Label(frame2, text="CARID").place(x=150, y=270)
    carbook = Entry(frame2, textvariable=ent4)
    carbook.place(x=200, y=270)

    Label(frame2, text="NAME").place(x=150, y=300)
    carname = Entry(frame2, textvariable=ent5)
    carname.place(x=200, y=300)

    Label(frame2, text="EMAIL").place(x=150, y=330)
    carmail = Entry(frame2, textvariable=ent6)
    carmail.place(x=200, y=330)

    Label(frame2, text="DATE").place(x=150, y=360)
    cardate = Entry(frame2, textvariable=ent7)
    cardate.place(x=200, y=360)

    Label(frame2, text="LOCATION").place(x=150, y=390)
    carloc = Entry(frame2, textvariable=ent8)
    carloc.place(x=220, y=390)

    Button(frame2, text="BOOK CAR", command=bookcar).place(x=200, y=420)
    Button(frame2, text="REFRESH", command=enter).place(x=290, y=420)

    Label(frame3, text="RETURN CAR PORTAL").place(x=190, y=10)
    Button(frame3, text="GO TO RETURN CAR", command=returncar).place(x=200, y=100)

    root.mainloop()

def submit():
    username = a.get()
    password = b.get()
    if username == "admin" and password == "admin":
        messagebox.showinfo("valid!", "welcome!")
        enter()
    else:
        messagebox.showwarning("not valid!!", "try again!")

r = Tk()
r.title("LOGIN CAR RENTAL SYSTEM")
r.geometry("500x500")
s = ttk.Style(r)
s.theme_use("clam")
a = StringVar()
b = StringVar()
Label(r, text="CAR RENTAL ADMIN LOGIN").pack()
Label(r, text="USERNAME").place(x=150, y=150)
g = Entry(r, textvariable=a)
g.place(x=220, y=150)
Label(r, text="PASSWORD").place(x=150, y=180)
h = Entry(r, textvariable=b)
h.place(x=220, y=180)
Button(r, text="SUBMIT", command=submit).place(x=250, y=220)


r.mainloop()